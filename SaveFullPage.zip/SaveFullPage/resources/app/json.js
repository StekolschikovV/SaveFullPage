// var jsonfile = require('jsonfile');
// var fs = require('fs');
//
// var file = 'data.json'
// var obj = {name: 'JP'}
// var newName = {}

// jsonfile.writeFile(file, obj, function (err) {
//     console.error(err)
// })
// var aaa = {
//     line: function () {
//         console.log(1)
//         aaa.RF();
//         console.log(3)
//     },
//     RF: async function () {
//         await jsonfile.readFile(file, function(err, obj) {
//             console.log(2)
//         })
//     }
// }
//
// aaa.line()


// console.log(4)
// async function a() {
//     await jsonfile.readFile(file, function(err, obj) {
//          console.log(5)
//     })
// }
// a()
// console.log(6)

