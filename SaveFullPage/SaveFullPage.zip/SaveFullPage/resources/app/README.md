npm start
http://5.tutcravt1.tutdomen.com/
npm install

electron-packager . myapp --ignore="node_modules/(electron-packager|electron-p rebuilt)" --platform=win32 --arch=ia32 --version=0.36.3 --overwrite --asar=false
