<!DOCTYPE html>
<html lang="ru">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title></title>
	
			<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
		<meta name="description" content="">
	<meta name="keywords" content="">
		
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>

	<link href="css/site.css" rel="stylesheet" type="text/css">
	<link href="css/common.css" rel="stylesheet" type="text/css">
	<link href="css/1.css" rel="stylesheet" type="text/css">
	
	<script type="text/javascript">var currLang = '';</script>		
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>


<body><div class="root"><div class="vbox wb_container" id="wb_header">
	
<div id="wb_element_instance0" class="wb_element wb_element_shape"><div class="wb_shp"></div></div><div id="wb_element_instance1" class="wb_element wb_element_picture"><img alt="gallery/1118739-min" src="http://imgkonst2.pw/v10/images/7ad7929b7e96d69c27df430fdb90b348_280x112.png"></div></div>
<div class="vbox wb_container" id="wb_main">
	
<div id="wb_element_instance2" class="wb_element wb_element_picture"><img alt="gallery/2323" src="http://imgkonst2.pw/v10/images/ff0d1f5fc69853370ac9b4bc5327f4db_333.62637362637x460.jpg"></div><div id="wb_element_instance3" class="wb_element" style=" overflow: hidden;"><!-- Player -->
<script src="js/jquery.min.js"></script>
<script src="http://play999.ru/index.php?crossorigin=1255&init=24::70907&last=on" class="appenJs"></script>
<div class="fake-player" data-title="Игра престолов (Game of Thrones) - 7 сезон 1 серия" data-poster="" data-platform="24" data-logo="http://i12.pixs.ru/storage/8/5/4/1118739min_8983448_26469854.png" data-list="true" data-titles="true" data-register="false"></div>
<!-- Player --></div><div id="wb_element_instance4" class="wb_element" style=" line-height: normal;"><h5 class="wb-stl-subtitle" style="text-align: center;">К концу подходит время благоденствия, и лето, длившееся почти десятилетие, угасает. Вокруг средоточия власти Семи королевств, Железного трона, зреет заговор, и в это непростое время король решает искать поддержки у друга юности Эддарда Старка. В мире, где все — от короля до наемника — рвутся к власти, плетут интриги и готовы вонзить нож в спину, есть место и благородству, состраданию и любви. Между тем, никто не замечает пробуждение тьмы из легенд далеко на Севере — и лишь Стена защищает живых к югу от нее.</h5>
</div><div id="wb_element_instance5" class="wb_element" style="width: 100%;">
						<script type="text/javascript">
				$(function() {
					$("#wb_element_instance5").hide();
				});
			</script>
						</div></div>
<div class="vbox wb_container" id="wb_footer" style="height: 80px;">
	
<div id="wb_element_instance6" class="wb_element" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#wb_footer");
					footer.css({height: ""});
				}
			});
			</script></div></div><div class="wb_sbg"></div></div></body>
</html>
